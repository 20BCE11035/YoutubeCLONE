const toggleBtn = document.getElementById("toggle");
const navBar = document.querySelector(".nav-bar");
const sideBar = document.querySelector(".side-bar");
const video = document.querySelector(".main-page .videos");
const vidCards = document.querySelectorAll(".videos .card");
const vidIcons = document.querySelectorAll(".videos .card .icons i");

// toggleBtn.addEventListener("click", function () {
//   navBar.classList.toggle("hide");
//   sideBar.classList.toggle("show");
// });
